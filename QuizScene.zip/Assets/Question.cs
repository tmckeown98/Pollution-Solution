﻿[System.Serializable]
public class Question {

    // Store the question and answer number
    public string question;
    public int answerNumber;

}
